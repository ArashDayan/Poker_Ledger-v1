/// Embedded PUBLIC key used to verify license signatures offline.
///
/// This file intentionally contains only the *public* half of the issuing
/// key pair. Anyone can read it out of the APK — that is fine and expected.
/// Verifying a signature requires only the public key; *creating* one
/// requires the private key, which never ships and lives with the owner in
/// `tool/license_keys/dev_private_key.pem`.
///
/// This is what makes the scheme resistant to key generation by an
/// attacker: unlike a checksum or an offline "algorithm" that can be
/// reverse-engineered out of the binary and re-implemented, forging a
/// signature here means breaking RSA-2048.
///
/// ROTATING THE KEY
/// Generate a new pair and replace the modulus below:
///   openssl genrsa -out dev_private_key.pem 2048
///   openssl rsa -in dev_private_key.pem -pubout -out dev_public_key.pem
///   python3 tool/issue_license.py --print-modulus
/// Every license issued under the previous key stops validating, so only
/// rotate when you intend exactly that.
library;

class LicenseKeys {
  LicenseKeys._();

  /// RSA modulus (n), hex encoded, 2048-bit.
  static const String modulusHex =
      'a37b543951fd47d320bf2ba4099ee7d6b3f88e01f3187acbc01db1f0d276a517'
      '17e1cd876f02d396c513827ff92d3bb35ea20a0af56ffe5a009e65333f158f41'
      'a33b8b5a4ecb1ff4fab0c78b3dc09d37346cecbf2913817d70cb8665f9818520'
      'f17e7f2566f512bf594c2319ac86cbbd8b06a3818d1119b903f0c9dc051c81e0'
      '1722b8245b205f74346e04fbc37551ff76b0bd9eaee82cdd2132d2b5b0eedf4c'
      '17d5a4af3189a209323bc3b9ed099d6fc595df58573ac39aca53aaad5214fd1d'
      '76db5b878633a919acc2d0d0bfd1e638bd7b602a68d2830ed175d0b2f4480b22'
      '84b2e09b6b586b30df576b195186de9407dfc71851a14363a707963344eca8df';

  /// Public exponent (e). 65537 is the standard choice.
  static const int exponent = 65537;

  /// Bumped only if the on-wire license format itself changes, so an old
  /// app can say "this license is newer than me" instead of silently
  /// failing verification for a reason the banker cannot act on.
  static const int supportedFormatVersion = 1;

  /// Prefix every license blob carries, so pasted text that is obviously
  /// not a license can be rejected with a useful message rather than a
  /// generic signature failure.
  static const String blobPrefix = 'PLK1';
}
