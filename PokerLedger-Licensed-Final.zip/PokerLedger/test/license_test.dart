// License / activation layer.
//
// These tests exercise the REAL cryptographic path against genuinely
// signed fixtures — there is no stubbed verifier. A forged or edited
// license must fail here for the same reason it fails on a phone.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:poker_ledger/license/device_identity.dart';
import 'package:poker_ledger/license/license_model.dart';
import 'package:poker_ledger/license/license_service.dart';
import 'package:poker_ledger/license/license_storage.dart';
import 'package:poker_ledger/license/license_verifier.dart';
import 'package:poker_ledger/models/enums.dart';
import 'package:poker_ledger/models/player.dart';
import 'package:poker_ledger/models/session.dart';
import 'package:poker_ledger/models/transaction.dart';
import 'package:poker_ledger/services/hive_service.dart';

import 'license_fixtures.dart';

late Directory _tmp;

Future<void> _open() async {
  _tmp = await Directory.systemTemp.createTemp('pl_license_');
  Hive.init(_tmp.path);
  Hive.registerAdapter(PlayerTagAdapter());
  Hive.registerAdapter(TransactionTypeAdapter());
  Hive.registerAdapter(SessionStatusAdapter());
  Hive.registerAdapter(AppCurrencyAdapter());
  Hive.registerAdapter(RakeModeAdapter());
  Hive.registerAdapter(SessionModeAdapter());
  Hive.registerAdapter(PlayerAdapter());
  Hive.registerAdapter(LedgerTransactionAdapter());
  Hive.registerAdapter(PokerSessionAdapter());
  await Hive.openBox<PokerSession>(HiveService.sessionsBox);
  await Hive.openBox<Player>(HiveService.playersBox);
  await Hive.openBox<LedgerTransaction>(HiveService.transactionsBox);
  await Hive.openBox(HiveService.settingsBox);
  DeviceIdentity.debugOverride(null);
}

Future<void> _close() async {
  DeviceIdentity.debugOverride(null);
  await Hive.deleteFromDisk();
  if (await _tmp.exists()) await _tmp.delete(recursive: true);
}

void main() {
  setUp(_open);
  tearDown(_close);

  group('signature verification', () {
    test('accepts a genuinely signed license', () {
      final result = LicenseVerifier.verify(kValidLicense);
      expect(result.valid, isTrue);
      expect(result.payload!.licenseId, 'PL-2026-0001');
      expect(result.payload!.customerName, 'Test Banker');
      expect(result.payload!.type, LicenseType.standard);
      expect(result.payload!.deviceLimit, 1);
      expect(result.payload!.isPerpetual, isTrue);
    });

    test('rejects a payload edited to raise the device limit', () {
      // The signature still belongs to the original payload, so this is
      // exactly what an attacker editing the blob would produce.
      final result = LicenseVerifier.verify(kTamperedLicense);
      expect(result.valid, isFalse);
      expect(result.error, LicenseError.badSignature);
    });

    test('rejects an empty key', () {
      expect(LicenseVerifier.verify('   ').error, LicenseError.empty);
    });

    test('rejects arbitrary text', () {
      expect(LicenseVerifier.verify('hello world').error,
          LicenseError.malformed);
    });

    test('rejects a truncated key', () {
      final short = kValidLicense.substring(0, kValidLicense.length - 40);
      expect(LicenseVerifier.verify(short).valid, isFalse);
    });

    test('rejects a single flipped signature character', () {
      final parts = kValidLicense.split('.');
      final sig = parts[2];
      final swapped = sig[0] == 'A' ? 'B' : 'A';
      final broken = '${parts[0]}.${parts[1]}.$swapped${sig.substring(1)}';
      expect(LicenseVerifier.verify(broken).valid, isFalse);
    });

    test('reports a newer format distinctly from a bad signature', () {
      expect(LicenseVerifier.verify('PLK9.abc.def').error,
          LicenseError.futureFormat);
    });

    test('tolerates whitespace and line wrapping from messaging apps', () {
      final mid = kValidLicense.length ~/ 2;
      final wrapped =
          '${kValidLicense.substring(0, mid)}\n   ${kValidLicense.substring(mid)}\n';
      expect(LicenseVerifier.verify(wrapped).valid, isTrue);
    });
  });

  group('expiry', () {
    test('a trial license is valid before its expiry', () {
      final result = LicenseVerifier.verify(kTrialLicense);
      expect(result.valid, isTrue);
      expect(result.payload!.type, LicenseType.trial);
      expect(result.payload!.isPerpetual, isFalse);
      expect(result.payload!.isExpiredAt(DateTime.now().toUtc()), isFalse);
    });

    test('an expired license verifies cryptographically but is refused',
        () async {
      // Important distinction: the signature is genuine. It is policy,
      // not crypto, that rejects it.
      expect(LicenseVerifier.verify(kExpiredLicense).valid, isTrue);

      final result = await LicenseService.activate(kExpiredLicense);
      expect(result.success, isFalse);
      expect(result.error, LicenseError.expired);
    });

    test('a perpetual license never expires', () {
      final payload = LicenseVerifier.verify(kValidLicense).payload!;
      expect(
        payload.isExpiredAt(DateTime.utc(2099)),
        isFalse,
      );
    });
  });

  group('activation lifecycle', () {
    test('a fresh install is not activated', () {
      expect(LicenseService.currentStatus().isActive, isFalse);
      expect(LicenseService.currentStatus().wasEverActivated, isFalse);
    });

    test('activating a valid key succeeds and persists', () async {
      final result = await LicenseService.activate(kValidLicense);
      expect(result.success, isTrue);

      final status = LicenseService.currentStatus();
      expect(status.isActive, isTrue);
      expect(status.payload!.licenseId, 'PL-2026-0001');
      expect(status.activatedAt, isNotNull);
      expect(status.deviceId, DeviceIdentity.id);
    });

    test('activation survives a simulated app restart', () async {
      await LicenseService.activate(kValidLicense);
      // Re-reading from storage is exactly what launch does.
      DeviceIdentity.debugOverride(null);
      expect(LicenseService.currentStatus().isActive, isTrue);
    });

    test('an invalid key does not activate', () async {
      final result = await LicenseService.activate('total-nonsense');
      expect(result.success, isFalse);
      expect(LicenseService.currentStatus().isActive, isFalse);
    });

    test('a failed activation does not overwrite a working one', () async {
      await LicenseService.activate(kValidLicense);
      await LicenseService.activate(kTamperedLicense);
      final status = LicenseService.currentStatus();
      expect(status.isActive, isTrue);
      expect(status.payload!.licenseId, 'PL-2026-0001');
    });

    test('deactivation releases the device', () async {
      await LicenseService.activate(kValidLicense);
      await LicenseService.deactivate();
      expect(LicenseService.currentStatus().isActive, isFalse);
    });
  });

  group('device binding', () {
    test('an activation copied to another device is refused', () async {
      await LicenseService.activate(kValidLicense);
      expect(LicenseService.currentStatus().isActive, isTrue);

      // Simulate the stored record being carried to a different install:
      // same encrypted blob, different device identity.
      DeviceIdentity.debugOverride('f' * 64);
      final status = LicenseService.currentStatus();
      expect(status.isActive, isFalse);
    });

    test('a license pre-bound to another device cannot be activated',
        () async {
      final result = await LicenseService.activate(kBoundLicense);
      expect(result.success, isFalse);
      expect(result.error, LicenseError.wrongDevice);
    });

    test('device id is stable across reads', () {
      final first = DeviceIdentity.id;
      DeviceIdentity.debugOverride(null);
      expect(DeviceIdentity.id, first);
    });

    test('short device id is derived from the full id', () {
      expect(DeviceIdentity.shortId.length, 14);
      expect(DeviceIdentity.shortId.replaceAll('-', ''),
          DeviceIdentity.id.substring(0, 12).toUpperCase());
    });

    test('a multi-device license reports its limit', () async {
      final result = await LicenseService.activate(kMultiDeviceLicense);
      expect(result.success, isTrue);
      expect(result.payload!.deviceLimit, 3);
    });
  });

  group('storage security', () {
    test('the activation is not stored as readable plaintext', () async {
      await LicenseService.activate(kValidLicense);
      final raw = HiveService.settings.get('license_activation_v1');
      expect(raw, isA<String>());
      // None of the meaningful fields should be greppable.
      expect(raw as String, isNot(contains('PL-2026-0001')));
      expect(raw, isNot(contains('Test Banker')));
      expect(raw, isNot(contains('PLK1')));
      expect(raw, isNot(contains('activated_at')));
    });

    test('editing the stored record is detected', () async {
      await LicenseService.activate(kValidLicense);
      final raw = HiveService.settings.get('license_activation_v1') as String;

      // Flip a character in the middle of the ciphertext.
      final mid = raw.length ~/ 2;
      final ch = raw[mid] == 'A' ? 'B' : 'A';
      await HiveService.settings.put(
        'license_activation_v1',
        raw.substring(0, mid) + ch + raw.substring(mid + 1),
      );

      // The HMAC fails, so the record is discarded rather than trusted.
      expect(LicenseStorage.read(), isNull);
      expect(LicenseService.currentStatus().isActive, isFalse);
    });

    test('a hand-written fake activation flag does not unlock the app',
        () async {
      await HiveService.settings.put(
          'license_activation_v1', 'activated=true');
      expect(LicenseService.currentStatus().isActive, isFalse);
    });
  });

  group('ledger data safety', () {
    test('activating and deactivating never touches ledger boxes',
        () async {
      final players = HiveService.players;
      final sessions = HiveService.sessions;
      final txns = HiveService.transactions;

      final player = Player(
        id: 'p1',
        sessionId: 's1',
        name: 'Ali',
        seatNumber: 1,
      );
      await players.put(player.id, player);

      final session = PokerSession(
        id: 's1',
        name: 'Friday Game',
        location: 'Home',
        dateTime: DateTime.now(),
        smallBlind: 1,
        bigBlind: 2,
        tableNumber: 1,
      );
      await sessions.put(session.id, session);

      final txn = LedgerTransaction(
        id: 't1',
        sessionId: 's1',
        playerId: 'p1',
        type: TransactionType.buyIn,
        amount: 100,
        timestamp: DateTime.now(),
      );
      await txns.put(txn.id, txn);

      await LicenseService.activate(kValidLicense);
      await LicenseService.deactivate();
      await LicenseService.activate(kValidLicense);

      expect(players.length, 1);
      expect(sessions.length, 1);
      expect(txns.length, 1);
      expect(players.get('p1')!.name, 'Ali');
      expect(players.get('p1')!.seatNumber, 1);
      expect(sessions.get('s1')!.name, 'Friday Game');
      expect(txns.get('t1')!.amount, 100);
    });
  });
}
