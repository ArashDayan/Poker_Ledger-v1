#!/usr/bin/env python3
"""Issue signed Poker Ledger license keys.

THIS SCRIPT IS FOR THE OWNER ONLY. It uses the PRIVATE key and must never
be shipped to a customer or bundled into the APK.

The app verifies licenses offline with the matching PUBLIC key embedded in
lib/license/license_keys.dart. Because signing needs the private key,
which lives only here, a customer cannot mint their own licenses even with
full access to the APK.

Requires only Python 3 + the `openssl` command line tool (no pip installs).

USAGE
  # Perpetual single-device license
  python3 tool/issue_license.py --customer "Reza" --id PL-2026-0001

  # 30-day trial
  python3 tool/issue_license.py --customer "Ali" --id PL-2026-0002 \
      --type trial --days 30

  # Three devices allowed
  python3 tool/issue_license.py --customer "Club" --id PL-2026-0003 \
      --devices 3

  # Lock to one specific device (customer sends you their Device ID)
  python3 tool/issue_license.py --customer "Sam" --id PL-2026-0004 \
      --bind <64-char-device-id>

  # Print the modulus to paste into lib/license/license_keys.dart
  python3 tool/issue_license.py --print-modulus

FIRST-TIME SETUP (already done in this repo)
  openssl genrsa -out tool/license_keys/dev_private_key.pem 2048
  openssl rsa -in tool/license_keys/dev_private_key.pem \
      -pubout -out tool/license_keys/dev_public_key.pem

  Then run --print-modulus and paste the result into license_keys.dart.

SECURITY
  Keep dev_private_key.pem out of any build you distribute and out of any
  public repository. If it leaks, generate a new pair, update
  license_keys.dart, and re-issue licenses.
"""

import argparse
import base64
import datetime
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
KEY_DIR = os.path.join(HERE, "license_keys")
PRIVATE_KEY = os.path.join(KEY_DIR, "dev_private_key.pem")
PUBLIC_KEY = os.path.join(KEY_DIR, "dev_public_key.pem")

PREFIX = "PLK1"
FORMAT_VERSION = 1


def b64url(data: bytes) -> str:
    """Base64url without padding — the app pads it back on decode."""
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def read_public_modulus() -> int:
    """Parse the SubjectPublicKeyInfo DER to recover (n, e)."""
    with open(PUBLIC_KEY) as fh:
        pem = fh.read()
    der = base64.b64decode(
        "".join(line for line in pem.splitlines() if "KEY" not in line)
    )

    def read_tlv(buf, i):
        tag = buf[i]
        i += 1
        length = buf[i]
        i += 1
        if length & 0x80:
            count = length & 0x7F
            length = int.from_bytes(buf[i:i + count], "big")
            i += count
        return tag, length, i

    _, _, i = read_tlv(der, 0)          # outer SEQUENCE
    _, alg_len, j = read_tlv(der, i)    # AlgorithmIdentifier
    i = j + alg_len
    _, _, i = read_tlv(der, i)          # BIT STRING
    i += 1                              # unused-bits byte
    _, _, i = read_tlv(der, i)          # RSAPublicKey SEQUENCE
    _, mod_len, i = read_tlv(der, i)    # modulus INTEGER
    modulus = int.from_bytes(der[i:i + mod_len], "big")
    return modulus


def print_modulus() -> None:
    n = read_public_modulus()
    hex_n = "%x" % n
    print(f"// {n.bit_length()}-bit modulus — paste into "
          f"lib/license/license_keys.dart\n")
    print("  static const String modulusHex =")
    chunks = [hex_n[k:k + 64] for k in range(0, len(hex_n), 64)]
    for idx, chunk in enumerate(chunks):
        tail = ";" if idx == len(chunks) - 1 else ""
        print(f"      '{chunk}'{tail}")


def sign(payload_bytes: bytes) -> bytes:
    """RSASSA-PKCS1-v1_5 over SHA-256, via openssl."""
    if not os.path.exists(PRIVATE_KEY):
        sys.exit(
            f"Private key not found at {PRIVATE_KEY}\n"
            "Generate one with:\n"
            f"  openssl genrsa -out {PRIVATE_KEY} 2048"
        )
    with tempfile.NamedTemporaryFile(delete=False) as payload_file:
        payload_file.write(payload_bytes)
        payload_path = payload_file.name
    sig_path = payload_path + ".sig"
    try:
        subprocess.run(
            ["openssl", "dgst", "-sha256", "-sign", PRIVATE_KEY,
             "-out", sig_path, payload_path],
            check=True,
        )
        with open(sig_path, "rb") as fh:
            return fh.read()
    finally:
        for path in (payload_path, sig_path):
            if os.path.exists(path):
                os.unlink(path)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Issue a signed Poker Ledger license key."
    )
    parser.add_argument("--customer", help="Customer display name")
    parser.add_argument("--customer-id", default="",
                        help="Your internal customer reference")
    parser.add_argument("--id", dest="license_id",
                        help="License ID, e.g. PL-2026-0001")
    parser.add_argument("--type", default="standard",
                        choices=["standard", "trial", "owner"])
    parser.add_argument("--days", type=int, default=None,
                        help="Valid for N days. Omit for perpetual.")
    parser.add_argument("--devices", type=int, default=1,
                        help="Device limit (default 1)")
    parser.add_argument("--bind", action="append", default=[],
                        help="Pre-bind to a specific Device ID. Repeatable.")
    parser.add_argument("--print-modulus", action="store_true",
                        help="Print the public modulus for license_keys.dart")
    args = parser.parse_args()

    if args.print_modulus:
        print_modulus()
        return

    if not args.customer or not args.license_id:
        parser.error("--customer and --id are required to issue a license")

    now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
    payload = {
        "v": FORMAT_VERSION,
        "license_id": args.license_id,
        "customer_id": args.customer_id or args.license_id,
        "customer_name": args.customer,
        "type": args.type,
        "issued_at": now.isoformat().replace("+00:00", "Z"),
        "device_limit": max(1, args.devices),
    }
    if args.days is not None:
        expiry = now + datetime.timedelta(days=args.days)
        payload["expires_at"] = expiry.isoformat().replace("+00:00", "Z")
    if args.bind:
        payload["bound_devices"] = args.bind

    # Compact, key-sorted JSON so the exact bytes are reproducible.
    payload_bytes = json.dumps(
        payload, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")

    signature = sign(payload_bytes)
    blob = f"{PREFIX}.{b64url(payload_bytes)}.{b64url(signature)}"

    print("=" * 62)
    print("LICENSE ISSUED")
    print("=" * 62)
    for key, value in payload.items():
        print(f"  {key:<14} {value}")
    print("=" * 62)
    print("Send this key to the customer:\n")
    print(blob)
    print()


if __name__ == "__main__":
    main()
