/// Embedded PUBLIC key used to verify license signatures offline.
///
/// This file intentionally contains only the *public* half of the issuing
/// key pair. Anyone can read it out of the APK — that is fine and expected.
/// Verifying a signature requires only the public key; *creating* one
/// requires the private key, which never ships and is held by the owner
/// outside this repository entirely.
///
/// This is what makes the scheme resistant to key generation by an
/// attacker: unlike a checksum or an offline "algorithm" that can be
/// reverse-engineered out of the binary and re-implemented, forging a
/// signature here means breaking RSA-2048.
///
/// This is the PRODUCTION key for Poker Ledger. Its private half is held
/// only by the owner, outside this repository, at
/// ~/.pokerledger/signing/pokerledger_production_private_key.pem —
/// so it is not in the source tree, not in git, and not in any ZIP of
/// this project.
///
/// ROTATING THE KEY
/// Generate a new pair and replace the modulus below:
///   KEYDIR=~/.pokerledger/signing
///   openssl genrsa -out $KEYDIR/pokerledger_production_private_key.pem 2048
///   openssl rsa -in $KEYDIR/pokerledger_production_private_key.pem \
///       -pubout -out $KEYDIR/pokerledger_production_public_key.pem
///   python3 tool/issue_license.py --print-modulus
/// Every license issued under the previous key stops validating, so only
/// rotate when you intend exactly that.
library;

class LicenseKeys {
  LicenseKeys._();

  /// RSA modulus (n), hex encoded, 2048-bit.
  static const String modulusHex =
      '9d9b56f5a374019e0483f3cbe0f5b21117fc19472eb0f3b6a0c3b03f44d30f2a'
      'cf64face788f54d1955bb861c53424a2f1a757b6b8d6e1c2f3b8c91be51613f3'
      'bd97eb8f4a9de723837fd846fcf8393354b9ce7afd3702cd755e32b2df8952a9'
      'c554d78f2f47809a8e41ae2a6b58690456d154d37035b7c83ea5a62e98b14caa'
      'ae9e90fe18711d0cc149c88e582d15ed09347b607d5a094cf66ad8869456f21e'
      '7f8794510bbd0b6c2fa31066e433d33b6a510755a9214ad7c0086111e5ffdca2'
      '849f42660f0b09701421d875d991b5490c24a0c5c2b9726de611c5f00d2b9708'
      '90b81238d8b555648ad8919f9368dd75c8125bc8c237ca4b7e4fe399eba5e6d9';

  /// Public exponent (e). 65537 is the standard choice.
  static const int exponent = 65537;

  /// Bumped only if the on-wire license format itself changes, so an old
  /// app can say "this license is newer than me" instead of silently
  /// failing verification for a reason the banker cannot act on.
  static const int supportedFormatVersion = 1;

  /// Prefix every license blob carries, so pasted text that is obviously
  /// not a license can be rejected with a useful message rather than a
  /// generic signature failure.
  static const String blobPrefix = 'PLK1';
}
