import 'package:hive_flutter/hive_flutter.dart';
import '../models/enums.dart';
import '../models/player.dart';
import '../models/session.dart';
import '../models/transaction.dart';

/// Thrown when local storage genuinely cannot be initialized even after
/// attempting per-box recovery — surfaced to the UI as a clear, honest
/// error screen instead of letting the app crash silently on launch.
class StorageInitException implements Exception {
  final String message;
  StorageInitException(this.message);
  @override
  String toString() => message;
}

/// Central place that owns all Hive boxes.
/// Offline-first by design: everything lives on-device. Swapping this
/// service out for a Firebase-backed one later is the only change needed
/// to move online, since screens/providers only ever talk to this class.
class HiveService {
  static const sessionsBox = 'sessions_box';
  static const playersBox = 'players_box';
  static const transactionsBox = 'transactions_box';
  static const settingsBox = 'settings_box';

  static Future<void> init() async {
    try {
      await Hive.initFlutter();
    } catch (e) {
      // Nothing works if this fails — no box to recover, no partial
      // start possible. Surface it plainly rather than crash unexplained.
      throw StorageInitException(
        'Could not initialize local storage on this device: $e',
      );
    }

    Hive.registerAdapter(PlayerTagAdapter());
    Hive.registerAdapter(TransactionTypeAdapter());
    Hive.registerAdapter(SessionStatusAdapter());
    Hive.registerAdapter(AppCurrencyAdapter());
    Hive.registerAdapter(RakeModeAdapter());
    Hive.registerAdapter(SessionModeAdapter());
    Hive.registerAdapter(PlayerAdapter());
    Hive.registerAdapter(LedgerTransactionAdapter());
    Hive.registerAdapter(PokerSessionAdapter());

    // Each box is opened independently and, if corrupted, individually
    // reset — a bad write killed mid-save in one box (e.g. a phone dying
    // during a save) should not take the whole app down, and should not
    // force wiping data that was actually fine. This is real recovery,
    // not just a caught exception: the app still launches successfully
    // afterward, at the cost of only the specific corrupted box's data.
    await _openBoxSafely<PokerSession>(sessionsBox, typed: true);
    await _openBoxSafely<Player>(playersBox, typed: true);
    await _openBoxSafely<LedgerTransaction>(transactionsBox, typed: true);
    await _openBoxSafely<dynamic>(settingsBox, typed: false);
  }

  static Future<void> _openBoxSafely<T>(String name, {required bool typed}) async {
    try {
      if (typed) {
        await Hive.openBox<T>(name);
      } else {
        await Hive.openBox(name);
      }
    } catch (_) {
      // Corrupted box on disk — delete just this one and start it fresh.
      try {
        await Hive.deleteBoxFromDisk(name);
        if (typed) {
          await Hive.openBox<T>(name);
        } else {
          await Hive.openBox(name);
        }
      } catch (e) {
        throw StorageInitException(
          "Local storage for '$name' could not be opened or recovered: $e",
        );
      }
    }
  }

  static Box<PokerSession> get sessions => Hive.box<PokerSession>(sessionsBox);
  static Box<Player> get players => Hive.box<Player>(playersBox);
  static Box<LedgerTransaction> get transactions =>
      Hive.box<LedgerTransaction>(transactionsBox);
  static Box get settings => Hive.box(settingsBox);
}
