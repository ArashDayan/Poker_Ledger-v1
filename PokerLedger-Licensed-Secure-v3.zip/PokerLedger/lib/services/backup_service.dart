import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/player.dart';
import '../models/session.dart';
import '../models/transaction.dart';
import 'hive_service.dart';

/// Full local backup/restore, independent of PDF/CSV reports (those are
/// per-session and lossy by design — signatures, voided transactions,
/// etc. are dropped for readability). This is the "everything, exactly
/// as stored" backup, meant to move data between devices or recover from
/// an accidental data-clear.
class BackupService {
  /// Bumped to 2 when settings were added to the payload. Version 1
  /// backups still restore correctly — the settings block is simply
  /// absent and current settings are left alone.
  static const _formatVersion = 2;

  /// Settings keys that are safe and useful to carry between devices.
  /// The PIN hash is deliberately EXCLUDED: restoring someone else's
  /// backup must never silently change the lock on this device, and a
  /// hash in a plain-text JSON file is an unnecessary exposure.
  static const _portableSettingKeys = [
    'language',
    'currency',
    'privacy_mode',
    'sound_effects_enabled',
  ];

  static Future<File> exportBackup() async {
    final data = {
      'formatVersion': _formatVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'sessions': HiveService.sessions.values.map((s) => s.toJson()).toList(),
      'players': HiveService.players.values.map((p) => p.toJson()).toList(),
      'transactions':
          HiveService.transactions.values.map((t) => t.toJson()).toList(),
      // Session JSON already carries tables, house rules, quick-rake
      // slots and timer state; player JSON carries seat, table id and
      // the sample signature; transaction JSON carries the captured
      // signature, notes, edit and void flags. So "everything" here is
      // those three collections plus app-level preferences.
      'settings': {
        for (final k in _portableSettingKeys)
          if (HiveService.settings.get(k) != null) k: HiveService.settings.get(k),
      },
    };
    final dir = await getApplicationDocumentsDirectory();
    final stamp = DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final file = File('${dir.path}/poker_ledger_backup_$stamp.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    return file;
  }

  /// Restores from a backup file. Uses `put` with each record's own id,
  /// so re-importing the same backup twice is safe (idempotent) rather
  /// than creating duplicates. Existing data with different ids is kept,
  /// not cleared — this is a merge, not a wipe.
  static Future<BackupImportResult> importBackup(File file) async {
    final raw = await file.readAsString();
    final Map<String, dynamic> data = jsonDecode(raw) as Map<String, dynamic>;

    final sessions = (data['sessions'] as List? ?? [])
        .cast<Map<String, dynamic>>()
        .map(PokerSession.fromJson)
        .toList();
    final players = (data['players'] as List? ?? [])
        .cast<Map<String, dynamic>>()
        .map(Player.fromJson)
        .toList();
    final transactions = (data['transactions'] as List? ?? [])
        .cast<Map<String, dynamic>>()
        .map(LedgerTransaction.fromJson)
        .toList();

    for (final s in sessions) {
      await HiveService.sessions.put(s.id, s);
    }
    for (final p in players) {
      await HiveService.players.put(p.id, p);
    }
    for (final t in transactions) {
      await HiveService.transactions.put(t.id, t);
    }

    // Preferences (v2+ backups only). Restoring an older backup leaves
    // the current settings untouched rather than resetting them.
    var settingsImported = 0;
    final settings = data['settings'];
    if (settings is Map) {
      for (final k in _portableSettingKeys) {
        if (!settings.containsKey(k)) continue;
        await HiveService.settings.put(k, settings[k]);
        settingsImported++;
      }
    }

    return BackupImportResult(
      sessionsImported: sessions.length,
      playersImported: players.length,
      transactionsImported: transactions.length,
      settingsImported: settingsImported,
    );
  }
}

class BackupImportResult {
  final int sessionsImported;
  final int playersImported;
  final int transactionsImported;
  final int settingsImported;
  const BackupImportResult({
    required this.sessionsImported,
    required this.playersImported,
    required this.transactionsImported,
    this.settingsImported = 0,
  });
}
