package com.pokerledger.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
